// ** React Imports
import { useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";

// ** Third Party Components
import { ReactSortable } from "react-sortablejs";

// ** Reactstrap Imports
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  CardText,
  Row,
  Col,
  ListGroupItem,
} from "reactstrap";

// ** Images
import img1 from "@src/assets/images/logo/MC.png";
import img2 from "@src/assets/images/mc/MC_main.png";

const array = {
  list1: [
    {
      id: "1",
      img: img1,
    },
  ],
  list2: [
    {
      id: "2",
      img: img1,
    },
    {
      id: "3",
      img: img1,
    },
  ],
  list3: [
    {
      id: "4",
      img: img2,
    },
    {
      id: "6",
      img: img1,
    },
  ],
  list4: [
    {
      id: "5",
      img: img1,
    },
  ],
};

const DndMultiple = () => {
  // ** States
  const [listArr1, setListArr1] = useState(array.list1);
  const [listArr2, setListArr2] = useState(array.list2);
  const [listArr3, setListArr3] = useState(array.list3);
  const [listArr4, setListArr4] = useState(array.list4);

  return (
    <Card>
      <CardHeader>
        <CardTitle tag="h4">Multiple Lists</CardTitle>
      </CardHeader>
      <CardBody>
        <Row>
          <Col md="12" sm="12">
            <h4 className="my-1">PIP,광고1</h4>
            <ReactSortable
              tag="ul"
              className="list-group list-group-flush sortable"
              group="shared-group"
              list={listArr3}
              setList={setListArr3}
              animation={200}
            >
              {listArr3.map((item) => {
                return (
                  <ListGroupItem className="draggable" key={item.id}>
                    <div className="d-flex align-items-center">
                      <div className="m-auto">
                        <img src={item.img} alt="Generic placeholder image" />
                      </div>
                    </div>
                  </ListGroupItem>
                );
              })}
            </ReactSortable>
          </Col>

          <Col md="6" sm="12">
            <h4 className="my-1">광고2</h4>
            <ReactSortable
              tag="ul"
              className="list-group list-group-flush sortable"
              group="shared-group"
              list={listArr1}
              setList={setListArr1}
              animation={200}
            >
              {listArr1.map((item) => {
                return (
                  <ListGroupItem className="draggable" key={item.id}>
                    <div className="d-flex align-items-center">
                      <div className="m-auto">
                        <img
                          src={item.img}
                          alt="Generic placeholder image"
                          width="500rem"
                          height="300rem"
                        />
                      </div>
                    </div>
                  </ListGroupItem>
                );
              })}
            </ReactSortable>
          </Col>
          <Col md="6" sm="12">
            <h4 className="my-1">광고3</h4>
            <ReactSortable
              tag="ul"
              className="list-group list-group-flush sortable"
              group="shared-group"
              list={listArr2}
              setList={setListArr2}
              animation={200}
            >
              {listArr2.map((item) => {
                return (
                  <ListGroupItem className="draggable" key={item.id}>
                    <div className="d-flex align-items-center">
                      <div className="m-auto">
                        <img
                          src={item.img}
                          alt="Generic placeholder image"
                          width="500rem"
                        />
                      </div>
                    </div>
                  </ListGroupItem>
                );
              })}
            </ReactSortable>
          </Col>
        </Row>
      </CardBody>
    </Card>
  );
};

export default DndMultiple;
