import { Mail, Home, Box } from "react-feather";

export default [
  {
    id: "home",
    title: "Home",
    icon: <Home size={20} />,
    navLink: "/home",
  },
  {
    id: "secondPage",
    title: "Second Page",
    icon: <Mail size={20} />,
    navLink: "/second-page",
  },
  {
    id: "dnd",
    title: "Dnd",
    icon: <Box size={20} />,
    navLink: "/dnd",
  },
  {
    id: "card",
    title: "Card",
    icon: <Box size={20} />,
    navLink: "/card",
  },
];
